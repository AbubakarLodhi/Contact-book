#include<iostream>

#include "Contact.h"

#include<string>

using namespace std;

int main()
{
	Contact c;
	/*c.AddContact("Amaan", "Muhammad", "amaan@gmail.com", "Male", "Lahore", "03220066001", "UMT", " NILL " );

	c.AddContact("Fahad", "Minhas", "hafiz@gmail.com", "Male", "Lahore", "03220064640", "UMT", "03144041470");

	c.AddContact("Ali", "Asghar", "ali@gmail.com", "Male", "Lahore", "03220000000", "UMT", " 03001234567 ");

	c.AddContact("Ubaid", "Zahid", "ubaid@gmail.com", "Male", "Samnabad", "03217654321", "UMT", " NILL ");

	c.DisplayContacts();

	c.SearchContact("03220066001");

	c.UpdateContact("03220064640", "03144041470");

	c.DeleteContact("03220000000");

	c.DisplayContacts();*/

	cout << "\t\t\t\t        \"\033[1;31mProject Data Structures and Algorithm\033[0m\"" << endl;
	cout << "\t\t\t\t\t      \"\033[32mPhone Book Application\033[0m\"" << endl;

	int num;
	do
	{
		cout << endl;
		cout << "\t\t\t <----------------------------------*----------------------------------->" << endl;
		cout << "\t\t\t|\t\t\t\t\t\t\t\t\t |" << endl;
		cout << "\t\t\t|\t\t\t\t\t\t\t\t\t |" << endl;
		cout << "\t\t\t|\t-------> Press \"\033[35m1\033[0m\" to \"\033[35mAdd\033[0m\" New Contact! <------- " << "\t\t |" << endl;
		cout << "\t\t\t|\t-------> Press \"\033[35m2\033[0m\" to \"\033[35mSearch\033[0m\" Contact! <-------" << "\t\t\ |" << endl;
		cout << "\t\t\t|\t-------> Press \"\033[35m3\033[0m\" to \"\033[35mDelete\033[0m\" Contact! <-------" << "\t\t\ |" << endl;
		cout << "\t\t\t|\t-------> Press \"\033[35m4\033[0m\" to \"\033[35mDisplay all Contact!\033[0m\"<------ - " << "\t\t | " << endl;
		cout << "\t\t\t|\t-------> Press \"\033[35m5\033[0m\" to \"\033[35mUpdate\033[0m\" Contact! <-------" << "\t\t |" << endl;
		cout << "\t\t\t|\t-------> Press \"\033[35m6\033[0m\" to \"\033[35mSort\033[0m\" Contacts By Name! <-------" << "\t\t |" << endl;
		cout << "\t\t\t|\t-------> Press \"\033[35m7\033[0m\" to Get \"\033[35mTotal Number\033[0m\" of Contact! <-------" << "\t |" << endl;
		cout << "\t\t\t|\t-------> Press \"\033[35m8\033[0m\" to Check if List \"\033[35mis Empty\033[0m\"! <------- " << "\t |" << endl;
		cout << "\t\t\t|\t-------> Press \"\033[35m9\033[0m\" to \"\033[35mUndo Last Add Operation\033[0m\"! <------ " << "\t |" << endl;
		cout << "\t\t\t|\t-------> Press \"\033[35m10\033[0m\" to \"\033[35mUndo Last Delete Operation\033[0m\"! <------ " << "\t |" << endl;
		cout << "\t\t\t|\t-------> Press \"\033[35m11\033[0m\" to Display \"\033[35mRecent Added Contacts\033[0m\"! <------ " << " |" << endl;
		cout << "\t\t\t|\t-------> Press \"\033[35m12\033[0m\" to Find \"\033[35mPosition of Contact in List\033[0m\"! <---- " << "|" << endl;
		cout << "\t\t\t|\t-------> Press \"\033[35m13\033[0m\" to \"\033[35mExit\033[0m\"! <-------" << "\t\t\t\t |" << endl;
		cout << "\t\t\t|\t\t\t\t\t\t\t\t\t |" << endl;
		cout << "\t\t\t|\t\t\t\t\t\t\t\t\t |" << endl;
		cout << "\t\t\t <----------------------------------*----------------------------------->" << endl;
		cout << "\t\t\t\t";
		cin >> num;
		cout << endl;

		string firstname, lastname, email, phonenum, otherphonenum, address, company, gender;
		string performoperations;
		if (num == 1)
		{
			//add new contact in list
			cout << "\t\t\t\tPlease Enter Person's First Name: ";
			cin >> firstname;

			cout << "\t\t\t\tPlease Enter Person's Last Name: ";
			cin >> lastname;

			cout << "\t\t\t\tPlease Enter Person's Email Address: ";
			cin >> email;

			cout << "\t\t\t\tPlease Enter Person's Gender: ";
			cin >> gender;

			cout << "\t\t\t\tPlease Enter Person's Address: ";
			cin >> address;

			cout << "\t\t\t\tPlease Enter Person's Contact Number: ";
			cin >> phonenum;

			cout << "\t\t\t\tPlease Enter Person's Other Contact Number: ";
			cin >> otherphonenum;

			cout << "\t\t\t\tPlease Enter Person's Company Name: ";
			cin >> company;

			cout << endl << endl;

			c.AddContact(firstname, lastname, email, gender, address, phonenum, company, otherphonenum);

		}
		else if (num == 2)
		{
			//search contact
			cout << "\t\t\t\tEnter Phone Number to Search: ";
			cin >> performoperations;
			c.SearchContact(performoperations);
		}
		else if (num == 3)
		{
			//delete contact
			cout << "\t\t\t\tEnter Phone Number to Delete: ";
			cin >> performoperations;
			c.DeleteContact(performoperations);
		}
		else if (num == 4)
		{

			c.DisplayContacts();
		}
		else if (num == 5)
		{
			cout << "\t\t\t\tEnter Old Phone Number: ";
			cin >> performoperations;
			cout << "\t\t\t\tEnter New Phone Number to change: ";
			string newnum;
			cin >> newnum;
			c.UpdateContact(performoperations, newnum);
		}
		else if (num == 6)
		{
			c.SortContactsByName();
			
		}
		else if (num == 7)
		{
			Contact::TotalContacts();
		}
		else if (num == 8)
		{
			c.isEmpty();
			if (!c.isEmpty())
			{
				cout << "\t\t\t\tList is Populated!" << endl << endl;;
			}
			else
			{
				cout << "\t\t\t\tList is Empty!" << endl << endl;;
			}
		}
		else if (num == 9)
		{
			c.UndoAdd();
		}
		else if (num == 10)
		{
			c.UndoDelete();
		}
		else if (num == 11)
		{
			c.ShowRecentAddedContact();
		}
		else if(num==12)
		{
			string num;
			cout << "\t\t\t\tEnter Contact Number to Find Position: ";
			cin >> num;
			c.FindLocation(num);
		}
		cout << endl;
	} while (num != 13);

	cout << endl;
	return 0;
}
