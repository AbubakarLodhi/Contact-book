#include "Contact.h"
#include <iostream>

using namespace std;

Contact::Contact()
{
	this->Head = nullptr;
	this->Tail = nullptr;
	this->Current = nullptr;
}

int Contact::total = 0;

Contact::Contact(string Firstname, string Lastname, string Emailaddress, string gender,
		string address, string Contactnumber, string company, string OtherPhoneNumber)
{
	Node* Newnode = Add_Node(Firstname, Lastname, Emailaddress, gender,
					address, Contactnumber, company, OtherPhoneNumber);

	Newnode->Address = address;
	Newnode->Company = company;
	Newnode->ContactNumber = Contactnumber;
	Newnode->EmailAddress = Emailaddress;
	Newnode->FirstName = Firstname;
	Newnode->Gender = gender;
	Newnode->LastName = Lastname;
	Newnode->Next = nullptr;
	Newnode->Prv = nullptr;
		
}

void Contact::AddContact(string Firstname, string Lastname, string Emailaddress, string gender,
				string address, string Contactnumber, string company, string OtherPhoneNumber)
{
	Node* newContact = Add_Node(Firstname, Lastname, Emailaddress, gender,
						address, Contactnumber, company, OtherPhoneNumber);
	if (this->Head == nullptr)
	{
		this->Head = this->Tail = newContact;
	}
	else
	{
		this->Current = Head;
		this->Tail->Next = newContact;
		newContact->Prv = Tail;
		this->Tail = newContact;
	}
	cout << "\t\t\t\tContact Added in List Successfuly!" << endl << endl;

}

void Contact::DeleteContact(const string& number)
{
	if (isEmpty())
	{
		cout << "\t\t\t\tList is Empty. No Data Found!" << endl << endl;
		return;
	}
	bool del = false;
	//check if first contact to be deleted
	if (this->Head->ContactNumber == number)
	{
		Node* temp = this->Head;
		this->Head = this->Head->Next;
		del = true;
		Deleted_node = recover_Deleted_node(temp->FirstName, temp->LastName, temp->EmailAddress, temp->Gender,
			temp->Address, temp->ContactNumber, temp->Company, temp->OtherContact);

		delete temp;
		total--;
		cout << "\t\t\t\tContact \"" << number << "\" Deleted Successfuly!" << endl << endl;
		return;
	}
	//check if last contact to be deleted
	if (this->Tail->ContactNumber == number)
	{
		Node* temp = this->Tail;
		this->Tail = this->Tail->Prv;
		this->Tail->Next = nullptr;
		del = true;
		Deleted_node = recover_Deleted_node(temp->FirstName, temp->LastName, temp->EmailAddress, temp->Gender,
											temp->Address, temp->ContactNumber, temp->Company, temp->OtherContact);
		delete temp;
		total--;
		cout << "\t\t\t\tContact \"" << number << "\" Deleted Successfuly!" << endl << endl;
		return;
	}
	this->Current = this->Head;
	while (Current->Next != nullptr)
	{
		if (number == Current->Next->ContactNumber)
		{
			Node* temp = this->Current->Next;
			this->Current->Next = temp->Next;
			this->Current->Next->Prv = this->Current;
			Deleted_node = recover_Deleted_node(temp->FirstName,temp->LastName,temp->EmailAddress, temp->Gender,
										temp->Address,temp->ContactNumber,temp->Company,temp->OtherContact);
			delete temp;
			total--;
			cout << "\t\t\t\tContact \"" << number << "\" Deleted Successfuly!" << endl << endl;
			del = true;
			return;
		}
		this->Current = this->Current->Next;
	}
	if (!del)
	{
		cout << "\t\t\t\tContact \"" << number << "\" not Found in the List!" << endl << endl;
	}
}

void Contact::SearchContact(const string& number)
{
	if (isEmpty())
	{
		cout << "\t\t\t\tList is Empty. No Data in List" << endl << endl;
		return;
	}
	bool found = false;

	this->Current = this->Head;
	while (this->Current != nullptr)
	{
		if (number == Current->ContactNumber)
		{
			cout << "\t\t\t\tContact \"" << number << "\" Found in List. Given Below: " << endl << endl;
			cout << "\t\t\t\t---> Name: " << this->Current->FirstName << " " << this->Current->LastName << endl;
			cout << "\t\t\t\t---> Email Address: " << this->Current->EmailAddress << endl;
			cout << "\t\t\t\t---> Gender: " << this->Current->Gender << endl;
			cout << "\t\t\t\t---> Address: " << this->Current->Address << endl;
			cout << "\t\t\t\t---> Contact Number: " << this->Current->ContactNumber << endl;
			cout << "\t\t\t\t---> Other Contact Number: " << this->Current->OtherContact << endl;
			cout << "\t\t\t\t---> Company: " << this->Current->Company << endl << endl;
			found = true;
			return;
		}

		this->Current = this->Current->Next;
	}

	if (!found)
	{
		cout << "\t\t\t\tContact \"" << number << "\" not Found in the List!" << endl;
	}
}


void Contact::UpdateContact(const string& oldnumber, const string& newnumber)
{
	if (isEmpty())
	{
		cout << "\t\t\t\tList is Empty. No Data in List" << endl << endl;
		return;
	}
	bool up = false;
	if (this->Head->ContactNumber == oldnumber)
	{
		this->Head->ContactNumber = newnumber;
		cout << "\t\t\t\tOld Contact \"" << oldnumber << "\" is Updated with";
		cout << "New Contact \"" << newnumber << "\"" << endl;
		cout << "\t\t\t\tNew Information Given Below: " << endl << endl;

		cout << "\t\t\t\t---> Name: " << this->Head->FirstName << " " << this->Head->LastName << endl;
		cout << "\t\t\t\t---> Email Addrsss: " << this->Head->EmailAddress << endl;
		cout << "\t\t\t\t---> Gender: " << this->Head->Gender << endl;
		cout << "\t\t\t\t---> Address: " << this->Head->Address << endl;
		cout << "\t\t\t\t---> Updated Contact Number: " << this->Head->ContactNumber << endl;
		cout << "\t\t\t\t---> Other Contact Number: " << this->Head->OtherContact << endl;
		cout << "\t\t\t\t---> Company: " << this->Head->Company << endl << endl;
		up = true;
		return;
	}
	this->Current = this->Head;
	while (Current != nullptr)
	{
		if (oldnumber == Current->Next->ContactNumber)
		{
			this->Current->Next->ContactNumber = newnumber;
			this->Current = this->Current->Next;

			cout << "\t\t\t\tOld Contact \"" << oldnumber << "\" is Updated with";
			cout << "New Contact \"" << newnumber << "\"" << endl;
			cout << "\t\t\t\tNew Information Given Below: " << endl << endl;

			cout << "\t\t\t\t---> Name: " << this->Current->FirstName << " " <<
				this->Current->LastName << endl;

			cout << "\t\t\t\t---> Email Addrsss: " << this->Current->EmailAddress << endl;
			cout << "\t\t\t\t---> Gender: " << this->Current->Gender << endl;
			cout << "\t\t\t\t---> Address: " << this->Current->Address << endl;
			cout << "\t\t\t\t---> Updated Contact Number: " << this->Current->ContactNumber << endl;
			cout << "\t\t\t\t---> Other Contact Number: " << this->Current->OtherContact << endl;
			cout << "\t\t\t\t---> Company: " << this->Current->Company << endl << endl;
			up = true;
			break;
		}
	}
	if (!up)
	{
		cout << "\t\t\t\tNo Contact Found to Update Number!" << endl << endl;
	}
}

void Contact::TotalContacts()
{
	cout << "\t\t\t\tTotal Number of Contacts are: " << total << endl << endl;
	return;
}
bool Contact::isEmpty()
{
	if (this->Head == nullptr)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void Contact:: SortContactsByName()
{
	if (isEmpty() || total == 1) 
	{
		cout << "\t\t\t\tList is already sorted or empty." << endl;
		return;
	}

	BubbleSort();
	cout << "\t\t\t\tContacts sorted by \"Name\" Successfuly." << endl;
}

void Contact::ShowRecentAddedContact()const
{
	if (this->Head==nullptr)
	{
		cout << "\t\t\t\tList is Empty No Data!" << endl << endl;
		return;
	}
	cout << "\t\t\t\tThe Recently Added Contact is Given Below: " << endl << endl;
	cout << "\t\t\t\t---> Name: " << this->Tail->FirstName << " " << this->Tail->LastName << endl;
	cout << "\t\t\t\t---> Email Addrsss: " << this->Tail->EmailAddress << endl;
	cout << "\t\t\t\t---> Gender: " << this->Tail->Gender << endl;
	cout << "\t\t\t\t---> Address: " << this->Tail->Address << endl;
	cout << "\t\t\t\t---> Contact Number: " << this->Tail->ContactNumber << endl;
	cout << "\t\t\t\t---> Other Contact Number: " << this->Tail->OtherContact << endl;
	cout << "\t\t\t\t---> Company: " << this->Tail->Company << endl << endl;
}

//to Delete last added contact;
void Contact ::UndoAdd()
{
	if (isEmpty())
	{
		cout << "\t\t\t\tLst is Empty" << endl << endl;
		return;
	}
	if(this->Head==this->Tail)
	{
		Node* temp = this->Head;
		this->Head = nullptr;
		delete temp;
		total--;
		cout << "\t\t\t\tLast Added Contact Deleted Successfuly!" << endl << endl;
	}
	else
	{
		Node* temp = this->Tail;
		this->Tail = this->Tail->Prv;
		this->Tail->Next = nullptr;
		delete temp;
		total--;
		cout << "\t\t\t\tLast Added Contact Deleted Successfuly!" << endl << endl;
	}
	
	return;
}

void Contact::UndoDelete()
{
	if (Deleted_node == nullptr)
	{
		cout << "\t\t\t\tNo Deleted Contact Found!" << endl << endl;
	}
	else
	{
		
		this->Tail->Next = Deleted_node;
		this->Tail = Deleted_node;
		cout << "\t\t\t\tThe Deleted Node Found and Attached with the List Successfuly!" << endl << endl;

		cout << "\t\t\t\t---> Name: " << Deleted_node->FirstName << " " << Deleted_node->LastName << endl;
		cout << "\t\t\t\t---> Email Addrsss: " << Deleted_node->EmailAddress << endl;
		cout << "\t\t\t\t---> Gender: " << Deleted_node->Gender << endl;
		cout << "\t\t\t\t---> Address: " << Deleted_node->Address << endl;
		cout << "\t\t\t\t---> Contact Number: " << Deleted_node->ContactNumber << endl;
		cout << "\t\t\t\t---> Other Contact Number: " << Deleted_node->OtherContact << endl;
		cout << "\t\t\t\t---> Company: " << Deleted_node->Company << endl << endl;
		Deleted_node = nullptr;
	}
}
void Contact::FindLocation(const string& num)
{
	int count = 1;
	bool found = false;
	this->Current = this->Head;
	while (this->Current != nullptr)
	{
		if (this->Current->ContactNumber == num)
		{
			found = true;
			break;
		}
		count++;
		this->Current = this->Current->Next;
	}
	cout << "\t\t\t\tThe Contact: " << num << " is at Position: " << count << "th in the List" << endl << endl;
	if (!found)
	{
		cout << "\t\t\t\tContact Not Present in the List!" << endl << endl;
	}
}

void Contact::DisplayContacts()
{
	if (isEmpty())
	{
		cout << "\t\t\t\tList is Empty. No Data in List" << endl << endl;
		return;
	}
	cout << "\t\t\t\tAll Contacts are Given Below: " << endl << endl;
	this->Current = this->Head;
	while (this->Current != nullptr)
	{
		cout << "\t\t\t\t---> Name: " << this->Current->FirstName << " " << this->Current->LastName << endl;
		cout << "\t\t\t\t---> Email Addrsss: " << this->Current->EmailAddress << endl;
		cout << "\t\t\t\t---> Gender: " << this->Current->Gender << endl;
		cout << "\t\t\t\t---> Address: " << this->Current->Address << endl;
		cout << "\t\t\t\t---> Contact Number: " << this->Current->ContactNumber << endl;
		cout << "\t\t\t\t---> Other Contact Number: " << this->Current->OtherContact << endl;
		cout << "\t\t\t\t---> Company: " << this->Current->Company << endl;
		this->Current = this->Current->Next;
		cout << endl << endl;
	}
}