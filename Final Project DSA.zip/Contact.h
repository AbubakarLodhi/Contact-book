#pragma once
#include <iostream>
using namespace std;
class Contact
{
private:
	struct Node
	{
		string FirstName;
		string LastName;
		string EmailAddress;
		string Gender;
		string Address;
		string ContactNumber;
		string Company;
		string OtherContact;
		Node* Next = nullptr;
		Node* Prv = nullptr;
	};

	Node* Add_Node(string Firstname, string Lastname, string Emailaddress, string gender,
		string address, string Contactnumber, string company, string OtherPhoneNumber)
	{
		Node* Newnode = new Node();
		Newnode->Address = address;
		Newnode->Company = company;
		Newnode->ContactNumber = Contactnumber;
		Newnode->EmailAddress = Emailaddress;
		Newnode->FirstName = Firstname;
		Newnode->Gender = gender;
		Newnode->LastName = Lastname;
		Newnode->OtherContact = OtherPhoneNumber;
		Newnode->Next = nullptr;
		Newnode->Prv = nullptr;
		total++;
		return Newnode;
	}

	void SwapNodes(Node* node1, Node* node2)
	{
		// Swapping the data of the nodes
		string temp;

		temp = node1->FirstName;
		node1->FirstName = node2->FirstName;
		node2->FirstName = temp;

		temp = node1->LastName;
		node1->LastName = node2->LastName;
		node2->LastName = temp;

		temp = node1->EmailAddress;
		node1->EmailAddress = node2->EmailAddress;
		node2->EmailAddress = temp;

		temp = node1->Gender;
		node1->Gender = node2->Gender;
		node2->Gender = temp;

		temp = node1->Address;
		node1->Address = node2->Address;
		node2->Address = temp;

		temp = node1->ContactNumber;
		node1->ContactNumber = node2->ContactNumber;
		node2->ContactNumber = temp;

		temp = node1->Company;
		node1->Company = node2->Company;
		node2->Company = temp;

		temp = node1->OtherContact;
		node1->OtherContact = node2->OtherContact;
		node2->OtherContact = temp;
	}

	void BubbleSort()
	{
		bool swapped;

		swapped = false;
	
		for (Node* i = this->Head; i != nullptr; i = i->Next)
		{
			

			for (Node* j = i->Next; j != nullptr; j = j->Next)
			{
				if (i->FirstName > j->FirstName)
				{
					SwapNodes(i, j);
					swapped = true;

				}
			}

			
			if (!swapped)
				break;
		}
	}

	Node* recover_Deleted_node(string Firstname, string Lastname, string Emailaddress, string gender,
		string address, string Contactnumber, string company, string OtherPhoneNumber)
	{
		Node* del = new Node();
		del->FirstName = Firstname;
		del->LastName = Lastname;
		del->EmailAddress = Emailaddress;
		del->Gender = gender;
		del->Address = address;
		del->ContactNumber = Contactnumber;
		del->Company = company;
		del->OtherContact = OtherPhoneNumber;
		del->Next = nullptr;
		del->Prv = nullptr;
		return del;

	}

	Node* Head;
	Node* Tail;
	Node* Current;
	static int total;

public:
	Node* Deleted_node = nullptr;

	Contact();
	Contact(string Firstname, string Lastname, string Emailaddress, string gender,
		string address, string Contactnumber, string company, string OtherPhoneNumber);

	void AddContact(string Firstname, string Lastname, string Emailaddress, string gender,
		string address, string Contactnumber, string company, string OtherPhoneNumber);

	void SearchContact(const string& number);
	void DeleteContact(const string& number);
	void DisplayContacts();
	void UpdateContact(const string& ldnumber,const string& newnumber);
	void SortContactsByName();
	static void TotalContacts();
	void ShowRecentAddedContact()const;
	void UndoAdd();
	void UndoDelete();
	void FindLocation(const string& num);
	bool isEmpty();
};

